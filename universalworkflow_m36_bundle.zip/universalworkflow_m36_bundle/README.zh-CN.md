# UniversalWorkflow M36 开发包说明

这个开发包不是原仓库的真实提交结果，而是基于当前已读源码结构所制作的 **M31→M36 架构级开发骨架**。

## 为什么不是直接改仓库

本轮会话中没有 GitHub 写入能力，也拿不到仓库工作树，因此无法：

- 直接在远端仓库上改文件
- 创建真实分支
- 生成真实 commit
- 在不提交中间改动的前提下做完整开发

所以本包采用最佳可执行方案：

1. 基于已读源码结构做第二轮复评
2. 直接给出 M31→M36 的中文实施蓝图
3. 把未来关键平台对象与服务骨架落成独立代码文件
4. 配套测试样例，验证这些骨架是自洽的

## 包内结构

- `docs/M31_ROUND2_REASSESSMENT.zh-CN.md`
- `docs/M31_TO_M36_MASTERPLAN.zh-CN.md`
- `packages/contracts/m36_platform_models.py`
- `packages/core_domain/m36_graph_compiler.py`
- `packages/core_domain/m36_role_factory.py`
- `packages/core_domain/m36_interaction_service.py`
- `packages/core_domain/m36_capability_service.py`
- `packages/core_domain/m36_automation_controller.py`
- `packages/core_domain/m36_eval_loop.py`
- `tests/test_m36_platform.py`

## 如何使用

推荐做法：

1. 先把这些文件放到你的真实仓库分支里
2. 以这些对象为平台新骨架
3. 把现有 `project_delivery`、capability plane、worker pool、operator packet、web UI 等逻辑逐步迁移到这些对象上
4. 再进入真实的 M32-M36 开发

## 核心价值

这个包最大的价值不在于“马上替换整个仓库”，而在于：

- 先把未来平台的标准对象定义清楚
- 避免后续继续无边界扩张
- 给多 agent、动态图编排、交互工作台、能力接入、自我升级提供一个统一起点
