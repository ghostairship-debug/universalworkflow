from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator, model_validator


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid4().hex[:12]}"


def utc_now() -> datetime:
    return datetime.now(UTC)


class RiskTier(StrEnum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class ReviewRequirement(StrEnum):
    none = "none"
    advisory = "advisory"
    human_required = "human_required"
    mandatory = "mandatory"


class SessionStatus(StrEnum):
    draft = "draft"
    clarifying = "clarifying"
    planned = "planned"
    approved = "approved"
    running = "running"
    completed = "completed"
    archived = "archived"


class TurnSpeaker(StrEnum):
    user = "user"
    assistant = "assistant"
    operator = "operator"
    planner = "planner"
    reviewer = "reviewer"
    system = "system"


class TurnKind(StrEnum):
    goal = "goal"
    clarification = "clarification"
    plan = "plan"
    approval = "approval"
    status = "status"
    followup = "followup"
    system = "system"


class RoleKind(StrEnum):
    fixed = "fixed"
    generated = "generated"
    promoted_template = "promoted_template"


class NodeKind(StrEnum):
    agent = "agent"
    tool = "tool"
    capability = "capability"
    human_gate = "human_gate"
    approval_gate = "approval_gate"
    parallel_map = "parallel_map"
    reducer = "reducer"
    eval = "eval"
    repair = "repair"
    publish = "publish"
    wait_event = "wait_event"
    schedule = "schedule"
    branch_decision = "branch_decision"


class EdgeConditionKind(StrEnum):
    always = "always"
    on_success = "on_success"
    on_failure = "on_failure"
    on_decision = "on_decision"
    on_signal = "on_signal"


class CapabilityTransport(StrEnum):
    local_process = "local_process"
    mcp_stdio = "mcp_stdio"
    mcp_http = "mcp_http"
    worker_pool = "worker_pool"
    runtime_gateway = "runtime_gateway"
    session_runtime = "session_runtime"
    hosted_api = "hosted_api"


class CapabilitySideEffectLevel(StrEnum):
    read_only = "read_only"
    artifact_only = "artifact_only"
    bounded_mutation = "bounded_mutation"
    session_write = "session_write"
    remote_dispatch = "remote_dispatch"


class SandboxMode(StrEnum):
    local_readonly = "local_readonly"
    local_mutation_bounded = "local_mutation_bounded"
    remote_ephemeral = "remote_ephemeral"
    remote_durable = "remote_durable"


class MemoryKind(StrEnum):
    session = "session"
    run = "run"
    artifact = "artifact"
    skill = "skill"
    policy = "policy"


class EvalStatus(StrEnum):
    passed = "passed"
    failed = "failed"
    warning = "warning"


class PromotionState(StrEnum):
    proposed = "proposed"
    accepted = "accepted"
    rejected = "rejected"
    superseded = "superseded"


class AutomationActionKind(StrEnum):
    resume_run = "resume_run"
    request_review = "request_review"
    reconcile_run = "reconcile_run"
    reroute_role = "reroute_role"
    emit_alert = "emit_alert"
    no_op = "no_op"


class ConversationTurn(BaseModel):
    turn_id: str = Field(default_factory=lambda: new_id("turn"))
    speaker: TurnSpeaker
    kind: TurnKind
    content: str = Field(min_length=1)
    references: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utc_now)


class IntentPacket(BaseModel):
    intent_id: str = Field(default_factory=lambda: new_id("intent"))
    goal: str = Field(min_length=3)
    constraints: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(default_factory=list)
    requested_delivery_mode: str | None = None
    requested_risk_tier: RiskTier = RiskTier.medium
    preferred_roles: list[str] = Field(default_factory=list)
    repo_targets: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ClarificationState(BaseModel):
    needs_clarification: bool = False
    questions: list[str] = Field(default_factory=list)
    assumptions: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _sync_needs_clarification(self) -> "ClarificationState":
        if self.questions:
            self.needs_clarification = True
        return self


class PlanDraft(BaseModel):
    plan_id: str = Field(default_factory=lambda: new_id("plan"))
    session_id: str
    summary: str = Field(min_length=8)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    graph_template_id: str
    proposed_roles: list[str] = Field(default_factory=list)
    candidate_dynamic_roles: list[str] = Field(default_factory=list)
    review_requirement: ReviewRequirement = ReviewRequirement.advisory
    risk_tier: RiskTier = RiskTier.medium


class LaunchDecision(BaseModel):
    decision_id: str = Field(default_factory=lambda: new_id("launch"))
    session_id: str
    selected_plan_id: str
    approved: bool
    approval_reason: str = Field(min_length=1)
    selected_graph_template_id: str
    human_gates_enabled: bool = True
    execution_mode: str = "guided_workbench"


class FollowupRequest(BaseModel):
    request_id: str = Field(default_factory=lambda: new_id("followup"))
    session_id: str
    target_run_id: str | None = None
    instruction: str = Field(min_length=3)
    desired_action: str
    impact_scope: str
    requires_recompile: bool = True


class IntentSession(BaseModel):
    session_id: str = Field(default_factory=lambda: new_id("session"))
    status: SessionStatus = SessionStatus.draft
    turns: list[ConversationTurn] = Field(default_factory=list)
    latest_intent: IntentPacket | None = None
    clarification_state: ClarificationState = Field(default_factory=ClarificationState)
    active_plan: PlanDraft | None = None
    latest_launch_decision: LaunchDecision | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    def add_turn(self, turn: ConversationTurn) -> None:
        self.turns.append(turn)
        self.updated_at = utc_now()


class TerminationRule(BaseModel):
    max_iterations: int = Field(default=8, ge=1)
    max_tool_calls: int = Field(default=16, ge=1)
    max_elapsed_seconds: int = Field(default=1800, ge=1)
    stop_on_human_gate: bool = True
    stop_on_low_progress: bool = True


class RoleEvaluationRubric(BaseModel):
    rubric_id: str = Field(default_factory=lambda: new_id("rubric"))
    role_id: str
    criteria: list[str] = Field(default_factory=list)
    failure_signals: list[str] = Field(default_factory=list)


class RoleTemplate(BaseModel):
    role_id: str
    display_name: str
    objective: str
    default_capabilities: list[str] = Field(default_factory=list)
    default_review_requirement: ReviewRequirement = ReviewRequirement.advisory
    max_iterations: int = Field(default=6, ge=1)
    allowed_repo_scopes: list[str] = Field(default_factory=list)
    success_criteria: list[str] = Field(default_factory=list)
    preferred_models: list[str] = Field(default_factory=list)
    monitorable: bool = True


class RoleSpec(BaseModel):
    role_id: str
    display_name: str
    role_kind: RoleKind
    objective: str
    success_criteria: list[str] = Field(default_factory=list)
    allowed_capabilities: list[str] = Field(default_factory=list)
    allowed_memory_namespaces: list[str] = Field(default_factory=list)
    allowed_repo_scope: list[str] = Field(default_factory=list)
    review_requirement: ReviewRequirement = ReviewRequirement.advisory
    max_iterations: int = Field(default=6, ge=1)
    termination_rule: TerminationRule = Field(default_factory=TerminationRule)
    escalation_target: str | None = None
    preferred_models: list[str] = Field(default_factory=list)
    visibility_level: str = "operator_visible"
    source_template_id: str | None = None
    generation_reason: str | None = None


class RoleAssignment(BaseModel):
    assignment_id: str = Field(default_factory=lambda: new_id("assign"))
    role_id: str
    node_id: str
    required: bool = True


class RoleExecutionContext(BaseModel):
    context_id: str = Field(default_factory=lambda: new_id("rolectx"))
    run_id: str | None = None
    session_id: str | None = None
    role_id: str
    repo_scope: list[str] = Field(default_factory=list)
    memory_scopes: list[str] = Field(default_factory=list)
    capability_overrides: list[str] = Field(default_factory=list)
    budget_envelope: dict[str, int] = Field(default_factory=dict)


class RetryPolicy(BaseModel):
    max_attempts: int = Field(default=2, ge=1)
    backoff_seconds: int = Field(default=30, ge=0)
    escalate_after_attempt: int = Field(default=2, ge=1)


class WatchdogPolicy(BaseModel):
    low_progress_seconds: int = Field(default=300, ge=30)
    max_stall_events: int = Field(default=2, ge=1)
    on_low_progress: str = "reroute_or_escalate"
    on_repeat_failure: str = "human_review"


class BarrierSpec(BaseModel):
    barrier_id: str = Field(default_factory=lambda: new_id("barrier"))
    label: str
    member_node_ids: list[str] = Field(default_factory=list)
    release_condition: str = "all_completed"


class ReducerSpec(BaseModel):
    reducer_id: str = Field(default_factory=lambda: new_id("reducer"))
    label: str
    input_node_ids: list[str] = Field(default_factory=list)
    merge_strategy: str = "summarize_then_select"
    output_contract: str = "merged_artifact_packet"


class ApprovalGateSpec(BaseModel):
    gate_id: str = Field(default_factory=lambda: new_id("gate"))
    label: str
    required_reviewers: list[str] = Field(default_factory=list)
    policy_requirement: ReviewRequirement = ReviewRequirement.human_required
    timeout_seconds: int = Field(default=86400, ge=60)


class NodeSpec(BaseModel):
    node_id: str
    title: str
    node_kind: NodeKind
    role_id: str | None = None
    capability_required: str | None = None
    inputs: list[str] = Field(default_factory=list)
    outputs: list[str] = Field(default_factory=list)
    review_requirement: ReviewRequirement = ReviewRequirement.advisory
    risk_tier: RiskTier = RiskTier.medium
    depends_on: list[str] = Field(default_factory=list)
    parallel_group: str | None = None
    retry_policy: RetryPolicy = Field(default_factory=RetryPolicy)
    watchdog_policy: WatchdogPolicy = Field(default_factory=WatchdogPolicy)
    metadata: dict[str, Any] = Field(default_factory=dict)


class EdgeSpec(BaseModel):
    edge_id: str = Field(default_factory=lambda: new_id("edge"))
    source_node_id: str
    target_node_id: str
    condition_kind: EdgeConditionKind = EdgeConditionKind.always
    condition_value: str | None = None


class ExecutionGraph(BaseModel):
    graph_id: str = Field(default_factory=lambda: new_id("graph"))
    session_id: str | None = None
    title: str
    summary: str
    nodes: list[NodeSpec]
    edges: list[EdgeSpec]
    barriers: list[BarrierSpec] = Field(default_factory=list)
    reducers: list[ReducerSpec] = Field(default_factory=list)
    approval_gates: list[ApprovalGateSpec] = Field(default_factory=list)
    role_assignments: list[RoleAssignment] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utc_now)

    @field_validator("nodes")
    @classmethod
    def _node_ids_unique(cls, nodes: list[NodeSpec]) -> list[NodeSpec]:
        seen: set[str] = set()
        for node in nodes:
            if node.node_id in seen:
                raise ValueError(f"duplicate node_id: {node.node_id}")
            seen.add(node.node_id)
        return nodes

    @model_validator(mode="after")
    def _edges_reference_known_nodes(self) -> "ExecutionGraph":
        node_ids = {node.node_id for node in self.nodes}
        for edge in self.edges:
            if edge.source_node_id not in node_ids or edge.target_node_id not in node_ids:
                raise ValueError("edges must reference known nodes")
        return self


class SandboxProfile(BaseModel):
    sandbox_id: str = Field(default_factory=lambda: new_id("sandbox"))
    mode: SandboxMode
    repo_scope: list[str] = Field(default_factory=list)
    network_allowed: bool = False
    writable_paths: list[str] = Field(default_factory=list)
    read_only_paths: list[str] = Field(default_factory=list)


class CapabilityTrustPolicy(BaseModel):
    policy_id: str = Field(default_factory=lambda: new_id("captrust"))
    max_risk_tier: RiskTier = RiskTier.high
    allow_mutation: bool = False
    require_human_gate_for_mutation: bool = True
    allowed_review_requirements: list[ReviewRequirement] = Field(
        default_factory=lambda: [
            ReviewRequirement.none,
            ReviewRequirement.advisory,
            ReviewRequirement.human_required,
            ReviewRequirement.mandatory,
        ]
    )


class UnifiedCapabilityDescriptor(BaseModel):
    capability_id: str
    display_name: str
    transport: CapabilityTransport
    side_effect_level: CapabilitySideEffectLevel
    trust_tier: str
    enabled: bool = True
    allowed_task_kinds: list[str] = Field(default_factory=list)
    review_requirement: ReviewRequirement = ReviewRequirement.advisory
    sandbox_profile: SandboxProfile
    trust_policy: CapabilityTrustPolicy = Field(default_factory=CapabilityTrustPolicy)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def allows_mutation(self) -> bool:
        return self.side_effect_level in {
            CapabilitySideEffectLevel.bounded_mutation,
            CapabilitySideEffectLevel.session_write,
            CapabilitySideEffectLevel.remote_dispatch,
        }


class CapabilitySelection(BaseModel):
    selection_id: str = Field(default_factory=lambda: new_id("capsel"))
    capability_id: str
    reason: str
    selected_for_role_id: str | None = None
    selected_for_node_id: str | None = None


class CapabilityInvocationEnvelope(BaseModel):
    invocation_id: str = Field(default_factory=lambda: new_id("invoke"))
    selection: CapabilitySelection
    risk_tier: RiskTier
    review_requirement: ReviewRequirement
    input_payload: dict[str, Any] = Field(default_factory=dict)
    sandbox_profile: SandboxProfile
    required_evidence: list[str] = Field(default_factory=list)


class CapabilityExecutionReceipt(BaseModel):
    receipt_id: str = Field(default_factory=lambda: new_id("receipt"))
    invocation_id: str
    capability_id: str
    succeeded: bool
    return_code: int | None = None
    artifact_refs: list[str] = Field(default_factory=list)
    evidence_refs: list[str] = Field(default_factory=list)
    trace_refs: list[str] = Field(default_factory=list)
    result_summary: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemoryItemBase(BaseModel):
    memory_id: str = Field(default_factory=lambda: new_id("memory"))
    memory_kind: MemoryKind
    namespace: str
    content: str = Field(min_length=1)
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)


class SessionMemoryItem(MemoryItemBase):
    memory_kind: MemoryKind = MemoryKind.session


class RunMemoryItem(MemoryItemBase):
    memory_kind: MemoryKind = MemoryKind.run


class ArtifactMemoryItem(MemoryItemBase):
    memory_kind: MemoryKind = MemoryKind.artifact


class SkillMemoryItem(MemoryItemBase):
    memory_kind: MemoryKind = MemoryKind.skill


class MemoryRetrievalPlan(BaseModel):
    plan_id: str = Field(default_factory=lambda: new_id("memplan"))
    query: str
    namespaces: list[str] = Field(default_factory=list)
    role_id: str | None = None
    max_items: int = Field(default=5, ge=1)
    include_session: bool = True
    include_run: bool = True
    include_artifact: bool = True
    include_skill: bool = True


class MemoryPromotionRule(BaseModel):
    rule_id: str = Field(default_factory=lambda: new_id("memrule"))
    source_kind: MemoryKind
    target_kind: MemoryKind
    min_importance: float = Field(default=0.8, ge=0.0, le=1.0)
    requires_review: bool = True


class EvalScenario(BaseModel):
    scenario_id: str = Field(default_factory=lambda: new_id("scenario"))
    name: str
    goal: str
    expected_signals: list[str] = Field(default_factory=list)
    rubric: list[str] = Field(default_factory=list)
    target_score: float = Field(default=0.8, ge=0.0, le=1.0)


class EvalEntry(BaseModel):
    scenario_id: str
    score: float = Field(ge=0.0, le=1.0)
    status: EvalStatus
    notes: list[str] = Field(default_factory=list)


class EvalReport(BaseModel):
    report_id: str = Field(default_factory=lambda: new_id("eval"))
    subject_id: str
    entries: list[EvalEntry]
    average_score: float = Field(ge=0.0, le=1.0)
    status: EvalStatus
    generated_at: datetime = Field(default_factory=utc_now)


class RepairPlan(BaseModel):
    repair_id: str = Field(default_factory=lambda: new_id("repair"))
    subject_id: str
    problem_summary: str
    proposed_actions: list[str] = Field(default_factory=list)
    risk_tier: RiskTier = RiskTier.medium
    requires_human_approval: bool = True


class UpgradeProposal(BaseModel):
    proposal_id: str = Field(default_factory=lambda: new_id("upgrade"))
    title: str
    subject_area: str
    rationale: str
    target_files: list[str] = Field(default_factory=list)
    expected_gain: str
    eval_report_id: str | None = None
    state: PromotionState = PromotionState.proposed


class CanaryPolicy(BaseModel):
    policy_id: str = Field(default_factory=lambda: new_id("canary"))
    rollout_percentage: int = Field(default=10, ge=1, le=100)
    stop_on_first_critical_failure: bool = True
    minimum_eval_runs: int = Field(default=5, ge=1)


class PromotionDecision(BaseModel):
    decision_id: str = Field(default_factory=lambda: new_id("promotion"))
    proposal_id: str
    state: PromotionState
    reason: str
    decided_at: datetime = Field(default_factory=utc_now)


class RunObservation(BaseModel):
    run_id: str
    status: str
    effective_review_state: str
    stalled_seconds: int = Field(default=0, ge=0)
    inspection_problem_count: int = Field(default=0, ge=0)
    risk_tier: RiskTier = RiskTier.medium
    next_action: str = "none"


class AutomationAction(BaseModel):
    action_id: str = Field(default_factory=lambda: new_id("autoact"))
    kind: AutomationActionKind
    run_id: str
    reason: str
    payload: dict[str, Any] = Field(default_factory=dict)
