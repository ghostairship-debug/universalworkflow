from __future__ import annotations

from dataclasses import dataclass

from packages.contracts.m36_platform_models import (
    ClarificationState,
    ConversationTurn,
    IntentPacket,
    IntentSession,
    LaunchDecision,
    PlanDraft,
    ReviewRequirement,
    RiskTier,
    SessionStatus,
    TurnKind,
    TurnSpeaker,
)


@dataclass(slots=True)
class InteractionHeuristics:
    ambiguity_goal_word_threshold: int = 5


class InteractionService:
    def __init__(self, heuristics: InteractionHeuristics | None = None) -> None:
        self.heuristics = heuristics or InteractionHeuristics()

    def create_session(self, goal: str, *, constraints: list[str] | None = None) -> IntentSession:
        intent = self._build_intent(goal, constraints=constraints or [])
        clarification = self._clarify(intent)
        session = IntentSession(
            status=SessionStatus.clarifying if clarification.needs_clarification else SessionStatus.planned,
            latest_intent=intent,
            clarification_state=clarification,
        )
        session.add_turn(
            ConversationTurn(
                speaker=TurnSpeaker.user,
                kind=TurnKind.goal,
                content=goal,
            )
        )
        if clarification.needs_clarification:
            for question in clarification.questions:
                session.add_turn(
                    ConversationTurn(
                        speaker=TurnSpeaker.assistant,
                        kind=TurnKind.clarification,
                        content=question,
                    )
                )
        else:
            session.active_plan = self.draft_plan(session)
        return session

    def draft_plan(self, session: IntentSession) -> PlanDraft:
        assert session.latest_intent is not None
        intent = session.latest_intent
        goal = intent.goal.lower()
        proposed_roles = ["planner", "retriever", "coder", "tester", "reviewer", "policy_guardian", "release_manager"]
        candidate_dynamic_roles: list[str] = []
        risks = ["需要守住 repo mutation、review 与 capability trust 边界。"]
        if "security" in goal:
            proposed_roles.append("security_reviewer")
            candidate_dynamic_roles.append("security_reviewer")
            risks.append("安全相关改动必须强制人工 gate。")
        if "performance" in goal:
            proposed_roles.append("performance_analyst")
            candidate_dynamic_roles.append("performance_analyst")
            risks.append("性能改动需要基准验证与回归对比。")
        if "localization" in goal:
            proposed_roles.append("localization_specialist")
            candidate_dynamic_roles.append("localization_specialist")
        review_requirement = (
            ReviewRequirement.mandatory
            if intent.requested_risk_tier in {RiskTier.high, RiskTier.critical}
            else ReviewRequirement.human_required
        )
        plan = PlanDraft(
            session_id=session.session_id,
            summary=f"围绕目标《{intent.goal}》生成 M36 平台化执行图。",
            assumptions=[
                "继续保持 local-first truth",
                "核心治理逻辑继续由代码控制",
                "模型只在受限节点内承担认知工作",
            ],
            risks=risks,
            graph_template_id="m36_engineering_platform_graph",
            proposed_roles=proposed_roles,
            candidate_dynamic_roles=candidate_dynamic_roles,
            review_requirement=review_requirement,
            risk_tier=intent.requested_risk_tier,
        )
        session.active_plan = plan
        session.status = SessionStatus.planned
        session.add_turn(
            ConversationTurn(
                speaker=TurnSpeaker.planner,
                kind=TurnKind.plan,
                content=plan.summary,
            )
        )
        return plan

    def approve_plan(self, session: IntentSession, *, approved: bool, reason: str) -> LaunchDecision:
        if session.active_plan is None:
            session.active_plan = self.draft_plan(session)
        decision = LaunchDecision(
            session_id=session.session_id,
            selected_plan_id=session.active_plan.plan_id,
            approved=approved,
            approval_reason=reason,
            selected_graph_template_id=session.active_plan.graph_template_id,
            human_gates_enabled=True,
            execution_mode="guided_workbench",
        )
        session.latest_launch_decision = decision
        session.status = SessionStatus.approved if approved else SessionStatus.planned
        session.add_turn(
            ConversationTurn(
                speaker=TurnSpeaker.operator if approved else TurnSpeaker.assistant,
                kind=TurnKind.approval,
                content=reason,
            )
        )
        return decision

    def _build_intent(self, goal: str, *, constraints: list[str]) -> IntentPacket:
        lowered = goal.lower()
        risk = RiskTier.medium
        if any(keyword in lowered for keyword in ("security", "auth", "credential", "permission")):
            risk = RiskTier.high
        if any(keyword in lowered for keyword in ("production", "release", "self-upgrade", "migration")):
            risk = max(risk, RiskTier.high, key=lambda x: list(RiskTier).index(x))
        return IntentPacket(goal=goal, constraints=constraints, requested_risk_tier=risk)

    def _clarify(self, intent: IntentPacket) -> ClarificationState:
        questions: list[str] = []
        words = [segment for segment in intent.goal.split() if segment.strip()]
        has_platform_anchor = any(term in intent.goal.lower() for term in ("repo", "api", "ui", "workflow", "graph", "agent"))
        is_short = len(words) < self.heuristics.ambiguity_goal_word_threshold and len(intent.goal) < 18
        if is_short and not has_platform_anchor:
            questions.append("你希望最终产出是代码、文档、补丁、发布包，还是完整工作流？")
        if not has_platform_anchor:
            questions.append("请补充目标对象：仓库、API、工作流、UI、还是平台能力。")
        return ClarificationState(questions=questions)
