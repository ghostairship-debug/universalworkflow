from __future__ import annotations

from dataclasses import dataclass

from packages.contracts.m36_platform_models import (
    CapabilityExecutionReceipt,
    CapabilityInvocationEnvelope,
    CapabilitySelection,
    CapabilitySideEffectLevel,
    CapabilityTransport,
    ReviewRequirement,
    RiskTier,
    SandboxMode,
    SandboxProfile,
    UnifiedCapabilityDescriptor,
)


@dataclass(slots=True)
class CapabilitySelectionRequest:
    required_capability: str
    risk_tier: RiskTier
    review_requirement: ReviewRequirement
    prefer_local: bool = True
    require_mutation: bool = False


def build_default_capability_descriptors() -> list[UnifiedCapabilityDescriptor]:
    return [
        UnifiedCapabilityDescriptor(
            capability_id="local_shell_readonly",
            display_name="Local Shell Readonly",
            transport=CapabilityTransport.local_process,
            side_effect_level=CapabilitySideEffectLevel.read_only,
            trust_tier="t0_builtin_local",
            allowed_task_kinds=["research", "inspect", "lint"],
            review_requirement=ReviewRequirement.advisory,
            sandbox_profile=SandboxProfile(mode=SandboxMode.local_readonly, read_only_paths=["."]),
        ),
        UnifiedCapabilityDescriptor(
            capability_id="opencode_patch_bounded",
            display_name="OpenCode Patch Bounded",
            transport=CapabilityTransport.local_process,
            side_effect_level=CapabilitySideEffectLevel.bounded_mutation,
            trust_tier="t1_local_bounded_mutation",
            allowed_task_kinds=["patch_apply", "repo_change"],
            review_requirement=ReviewRequirement.human_required,
            sandbox_profile=SandboxProfile(mode=SandboxMode.local_mutation_bounded, writable_paths=["."], read_only_paths=["tests", "docs"]),
        ),
        UnifiedCapabilityDescriptor(
            capability_id="mcp_readonly_workspace",
            display_name="MCP Readonly Workspace",
            transport=CapabilityTransport.mcp_stdio,
            side_effect_level=CapabilitySideEffectLevel.read_only,
            trust_tier="t1_local_mcp",
            allowed_task_kinds=["research", "inspect"],
            review_requirement=ReviewRequirement.advisory,
            sandbox_profile=SandboxProfile(mode=SandboxMode.local_readonly, read_only_paths=["."]),
        ),
        UnifiedCapabilityDescriptor(
            capability_id="remote_worker_pool",
            display_name="Remote Worker Pool",
            transport=CapabilityTransport.worker_pool,
            side_effect_level=CapabilitySideEffectLevel.remote_dispatch,
            trust_tier="t2_remote_worker_pool",
            allowed_task_kinds=["batch_exec", "heavy_exec"],
            review_requirement=ReviewRequirement.human_required,
            sandbox_profile=SandboxProfile(mode=SandboxMode.remote_ephemeral),
        ),
        UnifiedCapabilityDescriptor(
            capability_id="session_runtime",
            display_name="Sessionful External Runtime",
            transport=CapabilityTransport.session_runtime,
            side_effect_level=CapabilitySideEffectLevel.session_write,
            trust_tier="t2_session_runtime",
            allowed_task_kinds=["interactive_agent"],
            review_requirement=ReviewRequirement.human_required,
            sandbox_profile=SandboxProfile(mode=SandboxMode.remote_durable),
        ),
    ]


class CapabilityService:
    def __init__(self, descriptors: list[UnifiedCapabilityDescriptor] | None = None) -> None:
        self.descriptors = descriptors or build_default_capability_descriptors()

    def select(self, request: CapabilitySelectionRequest) -> UnifiedCapabilityDescriptor:
        candidates = [descriptor for descriptor in self.descriptors if descriptor.enabled]
        if request.require_mutation:
            candidates = [descriptor for descriptor in candidates if descriptor.allows_mutation()]
        if request.prefer_local:
            local_candidates = [
                descriptor
                for descriptor in candidates
                if descriptor.transport in {CapabilityTransport.local_process, CapabilityTransport.mcp_stdio}
            ]
            if local_candidates:
                candidates = local_candidates
        if request.risk_tier in {RiskTier.high, RiskTier.critical}:
            candidates = [
                descriptor
                for descriptor in candidates
                if descriptor.review_requirement in {ReviewRequirement.human_required, ReviewRequirement.mandatory}
            ] or candidates
        candidates.sort(
            key=lambda descriptor: (
                0 if descriptor.transport in {CapabilityTransport.local_process, CapabilityTransport.mcp_stdio} else 1,
                0 if descriptor.side_effect_level == CapabilitySideEffectLevel.read_only else 1,
            )
        )
        return candidates[0]

    def build_invocation_envelope(self, request: CapabilitySelectionRequest, role_id: str, node_id: str) -> CapabilityInvocationEnvelope:
        selected = self.select(request)
        return CapabilityInvocationEnvelope(
            selection=CapabilitySelection(
                capability_id=selected.capability_id,
                reason=f"risk={request.risk_tier}; review={request.review_requirement}; local={request.prefer_local}",
                selected_for_role_id=role_id,
                selected_for_node_id=node_id,
            ),
            risk_tier=request.risk_tier,
            review_requirement=request.review_requirement,
            sandbox_profile=selected.sandbox_profile,
            required_evidence=["execution_receipt", "trace_context", "artifact_refs"],
        )

    def synthesize_receipt(self, envelope: CapabilityInvocationEnvelope, *, succeeded: bool, summary: str) -> CapabilityExecutionReceipt:
        return CapabilityExecutionReceipt(
            invocation_id=envelope.invocation_id,
            capability_id=envelope.selection.capability_id,
            succeeded=succeeded,
            return_code=0 if succeeded else 1,
            artifact_refs=["state/artifacts/demo.md"] if succeeded else [],
            evidence_refs=["evidence/demo.json"],
            trace_refs=["trace/demo.json"],
            result_summary=summary,
        )
