from __future__ import annotations

from statistics import mean

from packages.contracts.m36_platform_models import (
    CanaryPolicy,
    EvalEntry,
    EvalReport,
    EvalScenario,
    EvalStatus,
    PromotionDecision,
    PromotionState,
    RepairPlan,
    UpgradeProposal,
)


class EvalLoopService:
    def build_report(self, subject_id: str, scenarios: list[EvalScenario], scored_entries: list[tuple[str, float, list[str]]]) -> EvalReport:
        scenario_map = {scenario.scenario_id: scenario for scenario in scenarios}
        entries: list[EvalEntry] = []
        for scenario_id, score, notes in scored_entries:
            target = scenario_map[scenario_id].target_score
            if score >= target:
                status = EvalStatus.passed
            elif score >= target - 0.1:
                status = EvalStatus.warning
            else:
                status = EvalStatus.failed
            entries.append(EvalEntry(scenario_id=scenario_id, score=score, status=status, notes=notes))
        average_score = mean(entry.score for entry in entries) if entries else 0.0
        if any(entry.status == EvalStatus.failed for entry in entries):
            status = EvalStatus.failed
        elif any(entry.status == EvalStatus.warning for entry in entries):
            status = EvalStatus.warning
        else:
            status = EvalStatus.passed
        return EvalReport(subject_id=subject_id, entries=entries, average_score=average_score, status=status)

    def propose_upgrade(self, report: EvalReport, *, subject_area: str, target_files: list[str]) -> UpgradeProposal | None:
        if report.status == EvalStatus.passed and report.average_score >= 0.85:
            return None
        return UpgradeProposal(
            title=f"{subject_area} quality improvement proposal",
            subject_area=subject_area,
            rationale=f"average_score={report.average_score:.2f}; status={report.status}",
            target_files=target_files,
            expected_gain="提高一致性、降低回归并缩短人工介入路径。",
            eval_report_id=report.report_id,
        )

    def build_repair_plan(self, report: EvalReport, *, subject_id: str) -> RepairPlan | None:
        failed = [entry for entry in report.entries if entry.status == EvalStatus.failed]
        if not failed:
            return None
        actions = [f"revisit_scenario:{entry.scenario_id}" for entry in failed]
        return RepairPlan(
            subject_id=subject_id,
            problem_summary="; ".join(actions),
            proposed_actions=actions,
            requires_human_approval=True,
        )

    def decide_promotion(self, proposal: UpgradeProposal, *, canary_policy: CanaryPolicy, eval_report: EvalReport) -> PromotionDecision:
        if eval_report.average_score >= 0.9 and eval_report.status == EvalStatus.passed:
            state = PromotionState.accepted
            reason = f"canary={canary_policy.rollout_percentage}% and eval passed"
        elif eval_report.status == EvalStatus.failed:
            state = PromotionState.rejected
            reason = "eval_failed"
        else:
            state = PromotionState.proposed
            reason = "needs_more_canary_data"
        return PromotionDecision(proposal_id=proposal.proposal_id, state=state, reason=reason)
