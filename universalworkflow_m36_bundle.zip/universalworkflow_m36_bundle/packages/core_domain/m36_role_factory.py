from __future__ import annotations

from dataclasses import dataclass

from packages.contracts.m36_platform_models import ReviewRequirement, RoleKind, RoleSpec, TerminationRule


@dataclass(slots=True)
class RoleGapInput:
    objective_gap: str
    required_deliverable_type: str
    domain: str
    risk_tier: str
    required_capabilities: list[str]
    expected_interaction_style: str
    max_autonomy_level: str
    review_requirement: ReviewRequirement
    budget_envelope: dict[str, int]


class RoleFactory:
    KEYWORD_MAP = {
        "security": ("security_reviewer", "Security Reviewer", ["security_review", "artifact_review"]),
        "performance": ("performance_analyst", "Performance Analyst", ["benchmark_exec", "artifact_review"]),
        "localization": ("localization_specialist", "Localization Specialist", ["translation_review", "artifact_review"]),
        "migration": ("migration_specialist", "Migration Specialist", ["data_migration_review", "artifact_review"]),
        "browser": ("browser_operator", "Browser Operator", ["browser_automation", "artifact_review"]),
    }

    def create_generated_role(self, gap: RoleGapInput) -> RoleSpec:
        lowered = " ".join(
            [
                gap.objective_gap.lower(),
                gap.required_deliverable_type.lower(),
                gap.domain.lower(),
            ]
        )
        role_id = "generated_specialist"
        display_name = "Generated Specialist"
        capabilities = list(gap.required_capabilities)
        for keyword, data in self.KEYWORD_MAP.items():
            if keyword in lowered:
                role_id, display_name, mapped = data
                capabilities = list(dict.fromkeys(capabilities + mapped))
                break
        return RoleSpec(
            role_id=role_id,
            display_name=display_name,
            role_kind=RoleKind.generated,
            objective=gap.objective_gap,
            success_criteria=[
                f"deliverable_type={gap.required_deliverable_type}",
                "scope_bounded",
                "operator_auditable",
            ],
            allowed_capabilities=capabilities,
            allowed_memory_namespaces=["run", "artifact", "policy"],
            allowed_repo_scope=["."],
            review_requirement=gap.review_requirement,
            max_iterations=4 if gap.max_autonomy_level == "bounded" else 6,
            termination_rule=TerminationRule(
                max_iterations=4 if gap.max_autonomy_level == "bounded" else 6,
                max_tool_calls=8,
                max_elapsed_seconds=1200,
                stop_on_human_gate=True,
                stop_on_low_progress=True,
            ),
            escalation_target="reviewer",
            preferred_models=["gpt-5.4-mini"],
            visibility_level="operator_visible",
            generation_reason=f"domain={gap.domain}; gap={gap.objective_gap}",
        )
