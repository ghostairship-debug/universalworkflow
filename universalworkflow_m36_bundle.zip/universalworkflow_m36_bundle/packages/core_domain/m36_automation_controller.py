from __future__ import annotations

from packages.contracts.m36_platform_models import (
    AutomationAction,
    AutomationActionKind,
    ReviewRequirement,
    RiskTier,
    RunObservation,
)


class AutomationController:
    def tick(self, observations: list[RunObservation]) -> list[AutomationAction]:
        actions: list[AutomationAction] = []
        for observation in observations:
            if observation.inspection_problem_count > 0:
                actions.append(
                    AutomationAction(
                        kind=AutomationActionKind.reconcile_run,
                        run_id=observation.run_id,
                        reason="inspection_problem_detected",
                        payload={"problem_count": observation.inspection_problem_count},
                    )
                )
                continue
            if observation.status == "prepared" and observation.next_action == "resume" and observation.stalled_seconds > 120:
                actions.append(
                    AutomationAction(
                        kind=AutomationActionKind.resume_run,
                        run_id=observation.run_id,
                        reason="prepared_run_stalled",
                    )
                )
                continue
            if observation.status == "awaiting_review" and observation.stalled_seconds > 600:
                actions.append(
                    AutomationAction(
                        kind=AutomationActionKind.request_review,
                        run_id=observation.run_id,
                        reason="awaiting_review_timeout",
                        payload={"escalate": observation.risk_tier in {RiskTier.high, RiskTier.critical}},
                    )
                )
                continue
            if observation.status == "running" and observation.stalled_seconds > 900:
                actions.append(
                    AutomationAction(
                        kind=AutomationActionKind.emit_alert,
                        run_id=observation.run_id,
                        reason="running_but_low_progress",
                        payload={"next_action": observation.next_action},
                    )
                )
                continue
            actions.append(
                AutomationAction(
                    kind=AutomationActionKind.no_op,
                    run_id=observation.run_id,
                    reason="no_automation_needed",
                )
            )
        return actions
