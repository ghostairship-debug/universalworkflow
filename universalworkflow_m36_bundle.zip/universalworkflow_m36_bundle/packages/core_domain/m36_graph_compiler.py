from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from packages.contracts.m36_platform_models import (
    ApprovalGateSpec,
    BarrierSpec,
    EdgeConditionKind,
    EdgeSpec,
    ExecutionGraph,
    IntentPacket,
    NodeKind,
    NodeSpec,
    ReducerSpec,
    ReviewRequirement,
    RiskTier,
    RoleAssignment,
    RoleSpec,
    RoleTemplate,
    RetryPolicy,
    WatchdogPolicy,
)


@dataclass(slots=True)
class GraphCompilerConfig:
    include_architect: bool = True
    include_release_manager: bool = True
    include_eval_and_repair_nodes: bool = True


def build_default_role_templates() -> list[RoleTemplate]:
    return [
        RoleTemplate(
            role_id="planner",
            display_name="Planner",
            objective="将自然语言意图转成结构化执行计划。",
            default_capabilities=["goal_analysis", "graph_planning"],
            success_criteria=["提出清晰的阶段拆解", "显式给出假设与风险"],
            preferred_models=["gpt-5.4-mini"],
        ),
        RoleTemplate(
            role_id="architect",
            display_name="Architect",
            objective="完成技术拆解、边界设计与依赖排序。",
            default_capabilities=["architecture_review"],
            success_criteria=["接口边界清晰", "实现顺序合理"],
            preferred_models=["gpt-5.4-mini"],
        ),
        RoleTemplate(
            role_id="retriever",
            display_name="Retriever",
            objective="检索仓库、文档、历史结论与外部证据。",
            default_capabilities=["repo_search", "web_research"],
            success_criteria=["证据充分", "引用明确"],
        ),
        RoleTemplate(
            role_id="coder",
            display_name="Coder",
            objective="在受控 repo scope 内完成修改。",
            default_capabilities=["bounded_patch_apply", "shell_exec"],
            default_review_requirement=ReviewRequirement.human_required,
            success_criteria=["满足验收条件", "改动范围受控"],
        ),
        RoleTemplate(
            role_id="tester",
            display_name="Tester",
            objective="验证功能、回归与边界条件。",
            default_capabilities=["test_exec", "lint_exec"],
            success_criteria=["输出结构化验证结论"],
        ),
        RoleTemplate(
            role_id="reviewer",
            display_name="Reviewer",
            objective="审查质量、风险与偏差。",
            default_capabilities=["artifact_review"],
            default_review_requirement=ReviewRequirement.human_required,
            success_criteria=["给出通过/拒绝与问题清单"],
        ),
        RoleTemplate(
            role_id="policy_guardian",
            display_name="Policy Guardian",
            objective="执行能力、风险、review、mutation 边界约束。",
            default_capabilities=["policy_check"],
            default_review_requirement=ReviewRequirement.mandatory,
            success_criteria=["高风险路径可被阻断"],
        ),
        RoleTemplate(
            role_id="monitor",
            display_name="Monitor",
            objective="检测卡死、低进展、重复失败与升级条件。",
            default_capabilities=["health_watch", "reconcile_preview"],
            success_criteria=["能及时触发干预"],
        ),
        RoleTemplate(
            role_id="release_manager",
            display_name="Release Manager",
            objective="生成交付包、发布建议与 ship/no-ship 决策。",
            default_capabilities=["release_packet"],
            default_review_requirement=ReviewRequirement.human_required,
            success_criteria=["输出完整交付与风险摘要"],
        ),
    ]


def instantiate_roles(dynamic_roles: Iterable[RoleSpec] | None = None) -> list[RoleSpec]:
    roles: list[RoleSpec] = []
    for template in build_default_role_templates():
        roles.append(
            RoleSpec(
                role_id=template.role_id,
                display_name=template.display_name,
                role_kind="fixed",
                objective=template.objective,
                success_criteria=template.success_criteria,
                allowed_capabilities=template.default_capabilities,
                allowed_memory_namespaces=["session", "run", "policy", "artifact"],
                allowed_repo_scope=template.allowed_repo_scopes,
                review_requirement=template.default_review_requirement,
                max_iterations=template.max_iterations,
                preferred_models=template.preferred_models,
                visibility_level="operator_visible",
                source_template_id=template.role_id,
            )
        )
    for role in dynamic_roles or []:
        roles.append(role)
    return roles


class GraphCompiler:
    def __init__(self, config: GraphCompilerConfig | None = None) -> None:
        self.config = config or GraphCompilerConfig()

    def compile_engineering_graph(
        self,
        intent: IntentPacket,
        *,
        dynamic_roles: Iterable[RoleSpec] | None = None,
    ) -> ExecutionGraph:
        roles = instantiate_roles(dynamic_roles)
        role_map = {role.role_id: role for role in roles}

        nodes: list[NodeSpec] = []
        edges: list[EdgeSpec] = []
        assignments: list[RoleAssignment] = []
        barriers: list[BarrierSpec] = []
        reducers: list[ReducerSpec] = []
        approval_gates: list[ApprovalGateSpec] = []

        def add_node(
            node_id: str,
            title: str,
            *,
            kind: NodeKind,
            role_id: str | None = None,
            capability_required: str | None = None,
            review_requirement: ReviewRequirement = ReviewRequirement.advisory,
            risk_tier: RiskTier = intent.requested_risk_tier,
            depends_on: list[str] | None = None,
            parallel_group: str | None = None,
            metadata: dict | None = None,
        ) -> None:
            nodes.append(
                NodeSpec(
                    node_id=node_id,
                    title=title,
                    node_kind=kind,
                    role_id=role_id,
                    capability_required=capability_required,
                    inputs=["goal", "constraints", "memory"],
                    outputs=["artifact", "status", "trace"],
                    review_requirement=review_requirement,
                    risk_tier=risk_tier,
                    depends_on=depends_on or [],
                    parallel_group=parallel_group,
                    retry_policy=RetryPolicy(max_attempts=2, backoff_seconds=15),
                    watchdog_policy=WatchdogPolicy(low_progress_seconds=300, max_stall_events=2),
                    metadata=metadata or {},
                )
            )
            if role_id is not None:
                assignments.append(RoleAssignment(role_id=role_id, node_id=node_id))

        add_node("planner", "意图转执行计划", kind=NodeKind.agent, role_id="planner", capability_required="goal_analysis")
        prev = "planner"

        if self.config.include_architect:
            add_node(
                "architect",
                "技术拆解与边界设计",
                kind=NodeKind.agent,
                role_id="architect",
                capability_required="architecture_review",
                depends_on=[prev],
                review_requirement=ReviewRequirement.advisory,
            )
            edges.append(EdgeSpec(source_node_id=prev, target_node_id="architect"))
            prev = "architect"

        add_node(
            "retriever",
            "证据检索与上下文打包",
            kind=NodeKind.agent,
            role_id="retriever",
            capability_required="repo_search",
            depends_on=[prev],
            review_requirement=ReviewRequirement.advisory,
        )
        edges.append(EdgeSpec(source_node_id=prev, target_node_id="retriever"))
        prev = "retriever"

        parallel_group = "build_and_verify"
        add_node(
            "coder",
            "受控开发与修改",
            kind=NodeKind.agent,
            role_id="coder",
            capability_required="bounded_patch_apply",
            review_requirement=ReviewRequirement.human_required,
            depends_on=[prev],
            parallel_group=parallel_group,
            risk_tier=max(intent.requested_risk_tier, RiskTier.high, key=lambda x: list(RiskTier).index(x)),
        )
        add_node(
            "tester",
            "验证与回归",
            kind=NodeKind.agent,
            role_id="tester",
            capability_required="test_exec",
            review_requirement=ReviewRequirement.advisory,
            depends_on=[prev],
            parallel_group=parallel_group,
        )
        edges.append(EdgeSpec(source_node_id=prev, target_node_id="coder"))
        edges.append(EdgeSpec(source_node_id=prev, target_node_id="tester"))
        barriers.append(BarrierSpec(label="build_and_verify", member_node_ids=["coder", "tester"]))

        reducer_inputs = ["coder", "tester"]
        for extra_role in dynamic_roles or []:
            add_node(
                extra_role.role_id,
                f"{extra_role.display_name} 并行专项节点",
                kind=NodeKind.agent,
                role_id=extra_role.role_id,
                capability_required=(extra_role.allowed_capabilities[0] if extra_role.allowed_capabilities else None),
                review_requirement=extra_role.review_requirement,
                depends_on=[prev],
                parallel_group=parallel_group,
                risk_tier=intent.requested_risk_tier,
                metadata={"generated_role": True},
            )
            edges.append(EdgeSpec(source_node_id=prev, target_node_id=extra_role.role_id))
            barriers[0].member_node_ids.append(extra_role.role_id)
            reducer_inputs.append(extra_role.role_id)

        add_node(
            "reviewer",
            "评审与问题清单汇总",
            kind=NodeKind.reducer,
            role_id="reviewer",
            capability_required="artifact_review",
            review_requirement=ReviewRequirement.human_required,
            depends_on=reducer_inputs,
        )
        reducers.append(ReducerSpec(label="review_merge", input_node_ids=reducer_inputs))
        for source in reducer_inputs:
            edges.append(EdgeSpec(source_node_id=source, target_node_id="reviewer"))

        add_node(
            "policy_guardian",
            "策略守卫与准入判断",
            kind=NodeKind.approval_gate,
            role_id="policy_guardian",
            capability_required="policy_check",
            review_requirement=ReviewRequirement.mandatory,
            depends_on=["reviewer"],
            risk_tier=max(intent.requested_risk_tier, RiskTier.high, key=lambda x: list(RiskTier).index(x)),
        )
        edges.append(
            EdgeSpec(
                source_node_id="reviewer",
                target_node_id="policy_guardian",
                condition_kind=EdgeConditionKind.on_success,
            )
        )
        approval_gates.append(
            ApprovalGateSpec(
                label="policy_and_human_gate",
                required_reviewers=["operator", "policy_guardian"],
                policy_requirement=ReviewRequirement.mandatory
                if intent.requested_risk_tier in {RiskTier.high, RiskTier.critical}
                else ReviewRequirement.human_required,
            )
        )

        if self.config.include_eval_and_repair_nodes:
            add_node(
                "eval",
                "评估与质量打分",
                kind=NodeKind.eval,
                role_id="monitor",
                capability_required="health_watch",
                review_requirement=ReviewRequirement.advisory,
                depends_on=["policy_guardian"],
            )
            add_node(
                "repair",
                "失败时的修复或回退建议",
                kind=NodeKind.repair,
                role_id="monitor",
                capability_required="reconcile_preview",
                review_requirement=ReviewRequirement.human_required,
                depends_on=["eval"],
            )
            edges.append(EdgeSpec(source_node_id="policy_guardian", target_node_id="eval"))
            edges.append(
                EdgeSpec(
                    source_node_id="eval",
                    target_node_id="repair",
                    condition_kind=EdgeConditionKind.on_failure,
                )
            )
            prev = "eval"
        else:
            prev = "policy_guardian"

        if self.config.include_release_manager:
            add_node(
                "release_manager",
                "交付包与发布建议",
                kind=NodeKind.publish,
                role_id="release_manager",
                capability_required="release_packet",
                review_requirement=ReviewRequirement.human_required,
                depends_on=[prev],
            )
            edges.append(EdgeSpec(source_node_id=prev, target_node_id="release_manager"))
            prev = "release_manager"

        return ExecutionGraph(
            session_id=None,
            title="M36 Engineering Platform Graph",
            summary=f"针对目标《{intent.goal}》生成的默认工程图。",
            nodes=nodes,
            edges=edges,
            barriers=barriers,
            reducers=reducers,
            approval_gates=approval_gates,
            role_assignments=assignments,
        )
