from __future__ import annotations

from packages.contracts.m36_platform_models import (
    EvalScenario,
    ReviewRequirement,
    RiskTier,
    RunObservation,
    SessionStatus,
)
from packages.core_domain.m36_automation_controller import AutomationController
from packages.core_domain.m36_capability_service import CapabilitySelectionRequest, CapabilityService
from packages.core_domain.m36_eval_loop import EvalLoopService
from packages.core_domain.m36_graph_compiler import GraphCompiler
from packages.core_domain.m36_interaction_service import InteractionService
from packages.core_domain.m36_role_factory import RoleFactory, RoleGapInput


def test_interaction_service_marks_short_goal_as_ambiguous() -> None:
    service = InteractionService()
    session = service.create_session("做一下优化")
    assert session.status == SessionStatus.clarifying
    assert session.clarification_state.needs_clarification is True
    assert len(session.clarification_state.questions) >= 1


def test_interaction_service_drafts_plan_for_specific_goal() -> None:
    service = InteractionService()
    session = service.create_session("为 repo workflow 平台加入动态角色与图编排能力")
    assert session.status == SessionStatus.planned
    assert session.active_plan is not None
    assert "planner" in session.active_plan.proposed_roles
    assert session.active_plan.graph_template_id == "m36_engineering_platform_graph"


def test_role_factory_generates_security_specialist() -> None:
    role = RoleFactory().create_generated_role(
        RoleGapInput(
            objective_gap="对身份与权限边界进行专项审查",
            required_deliverable_type="security review",
            domain="security",
            risk_tier="high",
            required_capabilities=["artifact_review"],
            expected_interaction_style="specialist",
            max_autonomy_level="bounded",
            review_requirement=ReviewRequirement.human_required,
            budget_envelope={"tokens": 8000},
        )
    )
    assert role.role_kind == "generated"
    assert role.role_id == "security_reviewer"
    assert "security_review" in role.allowed_capabilities


def test_graph_compiler_builds_engineering_graph_with_dynamic_role() -> None:
    interaction = InteractionService()
    session = interaction.create_session("为 repo workflow 平台加入 security graph orchestration")
    role = RoleFactory().create_generated_role(
        RoleGapInput(
            objective_gap="补充安全专项评审",
            required_deliverable_type="security review",
            domain="security",
            risk_tier="high",
            required_capabilities=["artifact_review"],
            expected_interaction_style="specialist",
            max_autonomy_level="bounded",
            review_requirement=ReviewRequirement.human_required,
            budget_envelope={"tokens": 5000},
        )
    )
    graph = GraphCompiler().compile_engineering_graph(session.latest_intent, dynamic_roles=[role])
    node_ids = {node.node_id for node in graph.nodes}
    assert {"planner", "retriever", "coder", "tester", "reviewer", "policy_guardian"} <= node_ids
    assert "security_reviewer" in node_ids
    assert any(barrier.label == "build_and_verify" for barrier in graph.barriers)


def test_capability_service_prefers_local_mutation_for_high_risk_patch() -> None:
    service = CapabilityService()
    envelope = service.build_invocation_envelope(
        CapabilitySelectionRequest(
            required_capability="patch_apply",
            risk_tier=RiskTier.high,
            review_requirement=ReviewRequirement.human_required,
            prefer_local=True,
            require_mutation=True,
        ),
        role_id="coder",
        node_id="coder",
    )
    assert envelope.selection.capability_id == "opencode_patch_bounded"
    assert envelope.sandbox_profile.mode == "local_mutation_bounded"


def test_automation_controller_emits_reconcile_for_inconsistent_run() -> None:
    actions = AutomationController().tick(
        [
            RunObservation(
                run_id="run_1",
                status="running",
                effective_review_state="not_requested",
                stalled_seconds=1200,
                inspection_problem_count=2,
                risk_tier=RiskTier.high,
                next_action="observe",
            )
        ]
    )
    assert actions[0].kind == "reconcile_run"


def test_eval_loop_proposes_upgrade_when_scores_are_low() -> None:
    loop = EvalLoopService()
    scenarios = [
        EvalScenario(name="graph quality", goal="compile graph", target_score=0.9),
        EvalScenario(name="interaction quality", goal="clarify intent", target_score=0.9),
    ]
    report = loop.build_report(
        "subject_a",
        scenarios,
        [
            (scenarios[0].scenario_id, 0.7, ["graph too rigid"]),
            (scenarios[1].scenario_id, 0.82, ["clarification acceptable"]),
        ],
    )
    proposal = loop.propose_upgrade(report, subject_area="orchestration", target_files=["packages/core_domain/m36_graph_compiler.py"])
    repair = loop.build_repair_plan(report, subject_id="subject_a")
    assert report.status == "failed"
    assert proposal is not None
    assert repair is not None
    assert "revisit_scenario" in repair.proposed_actions[0]
