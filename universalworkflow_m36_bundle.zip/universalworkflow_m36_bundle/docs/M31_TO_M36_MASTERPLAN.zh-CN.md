# M31→M36 总体实施蓝图（中文版）

日期：2026-04-21  
状态：实施蓝图  
目标：给出从当前仓库走向 M36 平台形态的分阶段开发方案，并把关键平台对象先落成代码骨架。

---

## 一、总目标

M36 目标形态不是“又一个多 agent 框架”，而是：

> **一个本地优先、治理内建、可编排、可扩展、可自然语言协作、可受控演进的 agentic engineering platform。**

它需要同时服务三类对象：

- 人类用户（产品使用者 / builder / operator）
- agent 角色（planner / coder / reviewer / monitor / specialist）
- 外部系统（worker pool / MCP / IDE / browser / CI / hosted provider）

---

## 二、M31 到 M36 的六个阶段

### M31：平台硬化期

核心目标：

- 把当前强内核整理成平台边界
- 抽出 interaction / orchestration / role / capability / automation / evolution 所需对象
- 建立 graph + role + capability 的统一骨架

交付重点：

- `IntentSession / IntentPacket / PlanDraft / LaunchDecision`
- `ExecutionGraph / NodeSpec / EdgeSpec / BarrierSpec / ReducerSpec / ApprovalGateSpec`
- `RoleTemplate / RoleSpec / RoleFactory`
- `UnifiedCapabilityDescriptor / CapabilityInvocationEnvelope`
- `AutomationController`
- `EvalLoopService`

### M32：角色系统与工作台期

核心目标：

- 建立固定角色注册表
- 建立即时角色生成与 promotion 机制
- 做出真正的 NL interaction workbench

### M33：能力生态与 pack 期

核心目标：

- 统一外部能力接入
- 建立 capability pack / role pack / skill pack / domain pack 边界
- 建立安装、校验、兼容与治理流程

### M34：分布式与长期运行期

核心目标：

- 强化 remote worker topology
- 强化 background job / queue / schedule / callback / wait-event
- 把自动化控制面做成熟

### M35：受控自进化期

核心目标：

- 用 eval + trace grading + canary + proposal 驱动系统改进
- 把 inspection / repair / mutation 和升级提案连起来

### M36：平台广化期

核心目标：

- 在已有稳定平台之上扩 domain
- 扩 product surfaces
- 扩生态，而不是反过来用生态倒逼架构

---

## 三、七个平面

### 1. Interaction Plane
负责：chat、guided launch、follow-up instruction、workbench。

### 2. Planning & Orchestration Plane
负责：goal -> plan -> graph compile -> supervise。

### 3. Role System Plane
负责：固定角色、动态角色、角色执行上下文、终止规则、评估 rubric。

### 4. Capability Runtime Plane
负责：tools、MCP、local adapters、remote workers、sessionful runtimes、provider integration。

### 5. Memory & Knowledge Plane
负责：session/run/artifact/skill/policy memory。

### 6. Governance & Observability Plane
负责：policy、audit、replay、trace、eval、repair、budget。

### 7. Kernel / Control Plane
负责：run lifecycle、snapshots、claims、leases、scheduler truth。

---

## 四、固定角色体系

推荐的固定核心角色：

- Planner
- Architect
- Retriever / Researcher
- Coder
- Tester / Verifier
- Reviewer
- Policy Guardian
- Monitor
- Release Manager

这些角色不是 prompt 别名，而应是平台级 `RoleTemplate`。

---

## 五、即时角色生成

动态角色必须满足：

- 临时性
- 结构化
- 可审计
- 可回收
- 可晋升（promotion）

动态角色输入至少应包含：

- objective gap
- deliverable type
- domain
- risk tier
- required capabilities
- interaction style
- max autonomy level
- review requirement
- budget envelope

输出则必须是标准 `RoleSpec`。

---

## 六、自动化编排

未来编排节点至少支持：

- AgentNode
- ToolNode
- CapabilityNode
- HumanGateNode
- ApprovalGateNode
- ParallelMapNode
- ReducerNode
- EvalNode
- RepairNode
- PublishNode
- WaitEventNode
- ScheduleNode
- BranchDecisionNode

同时应支持三种图来源：

- fixed template
- planner-derived graph
- dynamic hybrid graph

---

## 七、统一能力接入

能力接入必须统一进入同一逻辑家族：

- built-in tools
- MCP tools/resources/prompts
- local process adapters
- remote worker pools
- sessionful external runtimes
- hosted model/provider runtimes
- IDE/repo/browser/CI connectors
- long-running background jobs

统一对象建议：

- `UnifiedCapabilityDescriptor`
- `CapabilitySelection`
- `CapabilityInvocationEnvelope`
- `CapabilityExecutionReceipt`
- `CapabilityTrustPolicy`
- `SandboxProfile`

---

## 八、自然语言交互

理想流程：

1. 用户提出目标
2. 系统识别模糊点
3. 系统给出 plan / graph / risk / capability 预览
4. 用户确认或修改
5. 系统启动执行
6. 系统持续反馈
7. 用户通过 follow-up instruction 改变走向
8. 系统把自然语言变成结构化操作

这要求 interaction state 与 execution state 分离，但互相关联。

---

## 九、自动化控制面

自动化控制面至少应具备：

- prepared run 自动恢复规则
- awaiting_review 超时提醒与升级
- running 低进展告警
- inspection problem 自动触发 reconcile 建议
- 长任务的 wait-event / callback / checkpoint / resume

---

## 十、自我迭代升级

系统自我升级不能是无限制自动修改，而必须走：

1. detect friction
2. build eval report
3. propose upgrade
4. sandboxed execution
5. canary
6. promote / reject

推荐对象：

- `EvalScenario`
- `EvalReport`
- `UpgradeProposal`
- `RepairPlan`
- `CanaryPolicy`
- `PromotionDecision`

---

## 十一、这次代码骨架交付覆盖了什么

本次开发包已经先把以下对象和服务骨架实现为独立代码文件：

- 平台对象模型：`m36_platform_models.py`
- 图编译器：`m36_graph_compiler.py`
- 动态角色工厂：`m36_role_factory.py`
- 交互服务：`m36_interaction_service.py`
- 能力选择与调用 envelope：`m36_capability_service.py`
- 自动化控制器：`m36_automation_controller.py`
- 评估与升级闭环服务：`m36_eval_loop.py`

这意味着 M31→M36 的“协议层”和“骨架层”已经先落地成代码形态。

---

## 十二、实施顺序建议

最建议的落地顺序：

1. 先把这些对象并入真实仓库
2. 再把现有 `project_delivery` 迁移到 graph compiler
3. 再把 interaction plane 挂到现有 API / Web UI
4. 再把 capability plane 与 automation plane 接入现有 lifecycle
5. 最后逐步进入 M32-M36 的真实主线开发

---

## 十三、最终建议

不要把“开发到 M36”理解成一次性把所有功能写完。  
应该理解成：

> **先把支撑 M36 的平台骨架和关键协议定下来，并用代码把它们做成真实可落地的起点。**

本次交付正是按这个原则完成的。
