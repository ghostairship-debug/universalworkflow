# 第二轮架构评估（M31 入口评估，中文版）

日期：2026-04-21  
状态：第二轮复评  
目标：在上一轮评估的基础上，重新判断当前仓库是否适合直接冲向产品化、生态扩张和更深的自主升级，并给出进入 M31-M36 的现实边界。

---

## 一、结论先行

这次复评后的判断比上一轮更明确：

1. **当前仓库已经具备“控制平面内核”的基本形态**，不是普通 workflow demo。  
2. **当前最大的瓶颈不是能力不够，而是平台边界尚未彻底拉开。**
3. **如果现在直接冲 M32-M36 的全部产品目标，风险很高。**
4. **最优路径不是跳过 M31，而是把 M31 视为进入 M32-M36 的必要入口。**
5. **所谓“开发至 M36”在工程上不应理解为一次性把所有未来能力全写完，而应理解为：完成从当前内核到 M36 目标架构的骨架化、协议化和阶段化落地。**

也就是说，真正合理的“开发到 M36”不是“一口吃成胖子”，而是：

- 先把未来 M36 要依赖的核心对象定义清楚
- 再把关键平台骨架补齐
- 再把固定角色、动态角色、图编排、交互面、能力面、自动化面串起来
- 最后给出持续演进路线

---

## 二、第二轮复评看到的优点

### 1. 生命周期内核已经很扎实

当前代码已经明确区分：

- `create`
- `compile`
- `recompile`
- `resume`
- `awaiting_review`
- `completed/failed/cancelled`
- `inspect/reconcile/repair`

这不是普通 agent repo 的“一个 run() 到底”，而是显式生命周期控制。

### 2. 治理不是附属文档，而是运行逻辑

从现有结构看，review policy、audit、replay、inspection、repair 都已经进入系统主路径。  
这意味着未来做高风险自动化、repo mutation、动态角色时，并不需要从零重新发明治理层。

### 3. 编排、执行、观测三者已经初步同构

当前仓库已经形成了这样的雏形：

- 编排：`project_delivery` 与 plan graph / policy preview
- 执行：worker router、adapter、worker pool、scheduler authority
- 观测：summary / inspection / audit / replay packet / operator packet / dashboard

这说明仓库已经天然适合继续进化为平台。

### 4. repo mutation 路线已经证明“任意工程开发”不是空话

受控 patch、write set、test command、bounded fix loop，这些能力已经足以证明后续把“工程开发”做成平台一级任务族是现实可行的。

---

## 三、第二轮复评看到的核心问题

### 1. 现在仍然是“强内核、弱产品壳”

虽然 UI、TUI、CLI、API 都有，但它们更多是 operator-facing，而不是 user-facing workbench。  
这会导致：

- 最终用户的自然语言入口不稳定
- follow-up instruction 缺少统一会话对象
- 编排图、能力图、审计图还没有被真正封装成产品层交互对象

### 2. 多 agent 已经能做，但还没有统一协作拓扑

当前系统能跑多角色路径，但尚未彻底抽象成：

- 通用 graph DSL
- 通用 role contract
- 通用 reducer/barrier/gate 语义
- 通用动态角色注入机制

这会限制后续固定角色与即时角色生成能力的真正落地。

### 3. capability plane 仍然偏“拼图集合”，还不是统一执行协议

当前有：

- built-in tools
- MCP
- adapters
- worker pools
- sessionful external lanes
- runtime gateway

但它们还没有统一成一个稳定的 `CapabilityInvocationEnvelope` 体系。  
这会直接影响后续的：

- 通用能力接入
- pack 生态
- sandbox/trust/policy 一致性
- 统一 evidence / trace / audit

### 4. 自动化控制面仍然偏弱

现在有很多前台操作能力，但缺少真正的一等自动化控制面：

- 后台 controller loop
- 事件驱动恢复
- 低进展检测
- 长时间等待的超时/提醒/升级
- stale state 自动健康修复

没有这一层，就不能说系统真正具备“长期自治运营能力”。

### 5. 自我升级闭环还没真正成立

inspection / replay / audit / repair 已经很好，但还差：

- eval scenario
- trace grading
- canary policy
- upgrade proposal
- promotion decision

所以“自我迭代升级”当前还只是潜力，不是系统主干。

---

## 四、这次复评后的建议变化

上一轮更强调“不要盲目扩张”。  
这次复评进一步收紧为：

> **任何 M32-M36 的能力，如果不能挂在统一对象和统一协议上，就不应该直接进主线。**

这是一条更强的限制条件。

换句话说：

- 如果固定角色没有 `RoleSpec`，不要扩角色数
- 如果动态角色没有 `RoleFactory` 和 promotion rule，不要放开即时角色生成
- 如果 orchestration 没有 `ExecutionGraph/NodeSpec/EdgeSpec`，不要继续加复杂流程
- 如果 capability 没有统一 envelope，不要扩 provider breadth
- 如果 interaction 没有 `IntentSession/PlanDraft/LaunchDecision`，不要急着做花哨 workbench
- 如果 automation 没有 controller loop，不要谈深度自治
- 如果 evolution 没有 eval/canary/proposal/promotion，不要谈受控自升级

---

## 五、M31 是否仍然必要？

答案是：**比上一轮更必要。**

因为第二轮复评后可以明确确认：

- 当前仓库具备继续做大的基础
- 但也已经进入“若不先整边界，越扩越难收”的阶段

所以 M31 的必要性不是下降了，而是更强了。

---

## 六、如何理解“开发至 M36”

这句话不能按字面理解成：

- 一次会话内把未来所有目标全做完
- 当前仓库直接跃迁成最终成熟平台

更合理的工程解释应是：

1. 明确 M36 目标平台的最终结构
2. 定义支撑 M36 的核心对象和核心协议
3. 补出平台级骨架代码
4. 形成阶段化执行方案与测试样例
5. 让后续真实主线开发可以沿着这条轨道推进

因此，这次交付采取的策略是：

- 用中文完成二次复评与全阶段蓝图
- 用代码骨架把未来关键平台对象先落到文件层
- 用测试样例验证这些对象与编排骨架是自洽的

这不是“仓库最终完成态”，但这是“通往 M36 的正确工程起点”。

---

## 七、复评后的总体建议

### 保留的核心原则

- local-first truth 不动
- lifecycle explicitness 不动
- governance inside runtime 不动
- replay/audit/repair 路线不动
- bounded repo mutation 路线不动
- operator-facing projection 路线不动

### 必须新增的核心原则

- product surface 必须建立在 interaction API 之上
- orchestration 必须建立在 graph object 之上
- role system 必须建立在 role contract 之上
- capability expansion 必须建立在 unified capability envelope 之上
- self-evolution 必须建立在 eval/canary/proposal/promotion 之上

---

## 八、最终判断

第二轮复评后的最终判断是：

> 当前项目值得继续推进，而且值得推进到 M36 目标；  
> 但推进方式必须是“协议先行、骨架先行、平台边界先行”，而不是“功能数量先行”。

这也是本次交付包的设计原则。
